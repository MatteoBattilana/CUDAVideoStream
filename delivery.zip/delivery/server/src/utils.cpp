#include "../include/utils.hpp"

using namespace diff::utils;

int matsz::area() {
    return width*height;
}
